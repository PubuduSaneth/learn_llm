"""
agent.py
--------
Bakery Location Intelligence Agent.

Uses two Google-managed MCP servers:
  1. BigQuery MCP  — demographic, foot-traffic, pricing, and sales data
  2. Maps MCP      — place search, routing, and distance calculations

Run with:
    cd bakery_agent/       # parent directory of mcp_bakery_app/
    adk web .
"""

import os

import dotenv
from mcp_bakery_app import tools
from google.adk.agents import LlmAgent

dotenv.load_dotenv()

# ── Project config ────────────────────────────────────────────────────────────
PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT", "project_not_set")
DATASET    = "mcp_bakery"

# ── Initialise MCP toolsets ───────────────────────────────────────────────────
# Each call connects to the remote MCP server and discovers its tools.
# Toolsets are created once at module load time and reused across requests.
maps_toolset     = tools.get_maps_mcp_toolset()
bigquery_toolset = tools.get_bigquery_mcp_toolset()

# ── Agent definition ──────────────────────────────────────────────────────────
root_agent = LlmAgent(
    model="gemini-2.0-flash",          # use gemini-2.0-flash (gemini-3.1-pro-preview not yet GA)
    name="root_agent",
    instruction=f"""
You are an expert Bakery Location Intelligence Agent helping an entrepreneur
decide where to open a new bakery in the Los Angeles area.

You have access to two complementary data sources:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 1. BIGQUERY TOOLSET  — structured data in the `{DATASET}` dataset
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Run all jobs from project: {PROJECT_ID}
Always fully qualify table names: `{PROJECT_ID}.{DATASET}.TABLE_NAME`

Available tables and their purpose:
  • demographics          — zip_code, neighborhood, median_household_income,
                            total_population, median_age, bachelors_degree_pct,
                            foot_traffic_index
  • foot_traffic          — zip_code, time_of_day (morning/afternoon/evening),
                            foot_traffic_score
  • bakery_prices         — store_name, product_type, price, region, is_organic
  • sales_history_weekly  — week_start_date, store_location, product_type,
                            quantity_sold, total_revenue

Workflow for BigQuery questions:
  1. Use bigquery_list_datasets to confirm the dataset exists.
  2. Use bigquery_get_table_info to inspect schema before writing SQL.
  3. Use bigquery_execute_query to run SQL and retrieve results.
  4. If a query errors, read the error message, fix the SQL, and retry.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 2. MAPS TOOLSET  — real-world location intelligence
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Use for:
  • Searching for nearby bakeries, cafés, or competitors
  • Geocoding a zip code or address to lat/lng
  • Calculating driving time / distance between locations
  • Validating whether a specific neighbourhood is saturated

Always include a hyperlink to an interactive Google Maps view in your
response when showing location-based results.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RESPONSE GUIDELINES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Combine data insights with real-world location context in every answer.
• Be specific — cite zip codes, neighbourhoods, dollar amounts, and scores.
• Format numbers clearly: currency as $X.XX, percentages as X.X%.
• When you recommend a location, justify it with at least two data points
  from BigQuery AND one real-world observation from Maps.
• Keep responses concise but complete. Use bullet points for comparisons.
""",
    tools=[maps_toolset, bigquery_toolset],
)
